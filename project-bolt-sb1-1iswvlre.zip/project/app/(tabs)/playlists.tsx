import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Plus, Music } from 'lucide-react-native';

export default function PlaylistsScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Create Playlist</Text>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.createSection}>
          <TouchableOpacity style={styles.createButton}>
            <Plus size={24} color="#fff" />
            <Text style={styles.createText}>Create a new playlist</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.createButton}>
            <Music size={24} color="#fff" />
            <Text style={styles.createText}>Create from liked songs</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.searchSection}>
          <Text style={styles.sectionTitle}>Find songs for your playlist</Text>
          <TextInput
            style={styles.searchInput}
            placeholder="Search for songs or episodes"
            placeholderTextColor="#666"
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  header: {
    padding: 16,
    paddingTop: 60,
  },
  title: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  createSection: {
    marginTop: 24,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#282828',
    padding: 16,
    borderRadius: 4,
    marginBottom: 16,
  },
  createText: {
    color: '#fff',
    fontSize: 16,
    marginLeft: 16,
  },
  searchSection: {
    marginTop: 32,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  searchInput: {
    backgroundColor: '#282828',
    color: '#fff',
    padding: 12,
    borderRadius: 4,
    fontSize: 16,
  },
});