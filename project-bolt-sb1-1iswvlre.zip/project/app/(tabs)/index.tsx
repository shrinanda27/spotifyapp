import { View, Text, ScrollView, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Play } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import Header from '@/components/Header';
import MiniPlayer from '@/components/MiniPlayer';
import { artists, playlists } from '@/data/songs';

export default function HomeScreen() {
  const router = useRouter();

  const recentlyPlayed = [
    {
      id: '1',
      title: 'Daily Mix 1',
      type: 'playlist',
      imageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745',
    },
    {
      id: '2',
      title: 'Discover Weekly',
      type: 'playlist',
      imageUrl: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d',
    },
    {
      id: '3',
      title: 'Release Radar',
      type: 'playlist',
      imageUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f',
    },
  ];

  const handleItemPress = (item: { id: string, type: string }) => {
    if (item.type === 'playlist') {
      router.push(`/playlist/${item.id}`);
    } else if (item.type === 'artist') {
      router.push(`/artist/${item.id}`);
    }
  };

  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.content}>
        <LinearGradient
          colors={['#1DB954', '#121212']}
          style={styles.headerGradient}>
          <Text style={styles.greeting}>Good evening</Text>
        </LinearGradient>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recently played</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
            {recentlyPlayed.map((item) => (
              <TouchableOpacity 
                key={item.id} 
                style={styles.recentItem}
                onPress={() => handleItemPress(item)}>
                <Image source={{ uri: item.imageUrl }} style={styles.recentImage} />
                <Text style={styles.recentTitle}>{item.title}</Text>
                <TouchableOpacity style={styles.playButton}>
                  <Play size={24} color="#000" fill="#000" />
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Made for you</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
            {playlists.map((playlist) => (
              <TouchableOpacity 
                key={playlist.id} 
                style={styles.recommendedItem}
                onPress={() => router.push(`/playlist/${playlist.id}`)}>
                <Image source={{ uri: playlist.coverImage }} style={styles.recommendedImage} />
                <Text style={styles.recommendedTitle}>{playlist.name}</Text>
                <Text style={styles.recommendedDescription}>
                  {playlist.songs.length} songs
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular artists</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
            {artists.map((artist) => (
              <TouchableOpacity 
                key={artist.id} 
                style={styles.artistItem}
                onPress={() => router.push(`/artist/${artist.id}`)}>
                <Image source={{ uri: artist.image }} style={styles.artistImage} />
                <Text style={styles.artistName}>{artist.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Browse by genre</Text>
          <View style={styles.genreGrid}>
            {[
              { id: '1', name: 'Pop', color: '#FF4081' },
              { id: '2', name: 'Hip-Hop', color: '#7C4DFF' },
              { id: '3', name: 'Rock', color: '#FF5252' },
              { id: '4', name: 'Electronic', color: '#40C4FF' },
            ].map((genre) => (
              <TouchableOpacity
                key={genre.id}
                style={[styles.genreCard, { backgroundColor: genre.color }]}>
                <Text style={styles.genreText}>{genre.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
      <MiniPlayer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  content: {
    flex: 1,
  },
  headerGradient: {
    padding: 16,
    paddingTop: 32,
    height: 120,
  },
  greeting: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  horizontalScroll: {
    marginLeft: -8,
    paddingLeft: 8,
  },
  recentItem: {
    width: 150,
    marginRight: 16,
  },
  recentImage: {
    width: 150,
    height: 150,
    borderRadius: 8,
  },
  recentTitle: {
    color: '#fff',
    marginTop: 8,
    fontSize: 14,
  },
  playButton: {
    position: 'absolute',
    bottom: 30,
    right: 8,
    backgroundColor: '#1DB954',
    borderRadius: 50,
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  recommendedItem: {
    width: 200,
    marginRight: 16,
  },
  recommendedImage: {
    width: 200,
    height: 200,
    borderRadius: 8,
  },
  recommendedTitle: {
    color: '#fff',
    marginTop: 8,
    fontSize: 16,
    fontWeight: '600',
  },
  recommendedDescription: {
    color: '#b3b3b3',
    marginTop: 4,
    fontSize: 14,
  },
  artistItem: {
    width: 140,
    marginRight: 16,
    alignItems: 'center',
  },
  artistImage: {
    width: 140,
    height: 140,
    borderRadius: 70,
  },
  artistName: {
    color: '#fff',
    marginTop: 8,
    fontSize: 14,
    textAlign: 'center',
  },
  genreGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 16,
  },
  genreCard: {
    width: '47%',
    height: 100,
    borderRadius: 8,
    padding: 16,
    justifyContent: 'flex-end',
  },
  genreText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});