import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Play, Heart } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function LikedSongsScreen() {
  const likedSongs = [
    {
      id: '1',
      title: 'Song Title 1',
      artist: 'Artist 1',
      imageUrl: 'https://images.unsplash.com/photo-1611339555312-e607c8352fd7',
    },
    {
      id: '2',
      title: 'Song Title 2',
      artist: 'Artist 2',
      imageUrl: 'https://images.unsplash.com/photo-1611339555312-e607c8352fd7',
    },
    // Add more songs
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#5C67DE', '#121212']}
        style={styles.header}>
        <Text style={styles.title}>Liked Songs</Text>
        <Text style={styles.subtitle}>{likedSongs.length} songs</Text>
        <TouchableOpacity style={styles.playButton}>
          <Play size={24} color="#000" fill="#000" />
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView style={styles.songList}>
        {likedSongs.map((song) => (
          <TouchableOpacity key={song.id} style={styles.songItem}>
            <Image source={{ uri: song.imageUrl }} style={styles.songImage} />
            <View style={styles.songInfo}>
              <Text style={styles.songTitle}>{song.title}</Text>
              <Text style={styles.songArtist}>{song.artist}</Text>
            </View>
            <Heart size={24} color="#1DB954" fill="#1DB954" />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  header: {
    padding: 16,
    paddingTop: 60,
    height: 240,
  },
  title: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
    marginTop: 16,
  },
  subtitle: {
    color: '#b3b3b3',
    fontSize: 16,
    marginTop: 8,
  },
  playButton: {
    backgroundColor: '#1DB954',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
  },
  songList: {
    flex: 1,
    padding: 16,
  },
  songItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  songImage: {
    width: 48,
    height: 48,
    borderRadius: 4,
  },
  songInfo: {
    flex: 1,
    marginLeft: 12,
  },
  songTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  songArtist: {
    color: '#b3b3b3',
    fontSize: 14,
    marginTop: 4,
  },
});