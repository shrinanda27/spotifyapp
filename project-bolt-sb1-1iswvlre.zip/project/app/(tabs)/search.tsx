import { View, Text, TextInput, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Search as SearchIcon, TrendingUp } from 'lucide-react-native';
import { useState } from 'react';
import Header from '@/components/Header';
import MiniPlayer from '@/components/MiniPlayer';

export default function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');

  const trendingSearches = [
    { id: '1', term: 'Top 50 Global', type: 'Playlist' },
    { id: '2', term: 'Taylor Swift', type: 'Artist' },
    { id: '3', term: 'Hip Hop Mix', type: 'Playlist' },
    { id: '4', term: 'Chill Beats', type: 'Playlist' },
  ];

  const genres = [
    { id: '1', name: 'Pop', color: '#FF4081', imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819' },
    { id: '2', name: 'Hip-Hop', color: '#7C4DFF', imageUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f' },
    { id: '3', name: 'Rock', color: '#FF5252', imageUrl: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee' },
    { id: '4', name: 'Electronic', color: '#40C4FF', imageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745' },
    { id: '5', name: 'Jazz', color: '#FFB300', imageUrl: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629' },
    { id: '6', name: 'R&B', color: '#EC407A', imageUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f' },
  ];

  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.content}>
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <SearchIcon size={20} color="#000" />
            <TextInput
              style={styles.input}
              placeholder="What do you want to listen to?"
              placeholderTextColor="#666"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        {!searchQuery ? (
          <>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <TrendingUp size={24} color="#fff" />
                <Text style={styles.sectionTitle}>Trending searches</Text>
              </View>
              {trendingSearches.map((item) => (
                <TouchableOpacity key={item.id} style={styles.trendingItem}>
                  <Text style={styles.trendingTerm}>{item.term}</Text>
                  <Text style={styles.trendingType}>{item.type}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Browse all</Text>
              <View style={styles.genreGrid}>
                {genres.map((genre) => (
                  <TouchableOpacity
                    key={genre.id}
                    style={[styles.genreCard, { backgroundColor: genre.color }]}>
                    <Text style={styles.genreText}>{genre.name}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </>
        ) : (
          <View style={styles.searchResults}>
            {/* Search results will be implemented here */}
            <Text style={styles.noResults}>No results found for "{searchQuery}"</Text>
          </View>
        )}
      </ScrollView>
      <MiniPlayer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  content: {
    flex: 1,
  },
  searchContainer: {
    padding: 16,
    paddingTop: 8,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 4,
    padding: 12,
  },
  input: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
    color: '#000',
  },
  section: {
    padding: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
  },
  trendingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#282828',
  },
  trendingTerm: {
    color: '#fff',
    fontSize: 16,
  },
  trendingType: {
    color: '#b3b3b3',
    fontSize: 14,
  },
  genreGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 16,
  },
  genreCard: {
    width: '47%',
    height: 100,
    borderRadius: 8,
    padding: 16,
    justifyContent: 'flex-end',
  },
  genreText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  searchResults: {
    padding: 16,
  },
  noResults: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 32,
  },
});