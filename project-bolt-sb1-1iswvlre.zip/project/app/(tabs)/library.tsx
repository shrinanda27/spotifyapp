import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Filter, ArrowUpDown, Pin, Clock, Music2 } from 'lucide-react-native';
import Header from '@/components/Header';
import MiniPlayer from '@/components/MiniPlayer';

export default function LibraryScreen() {
  const pinnedItems = [
    {
      id: '1',
      title: 'Liked Songs',
      type: 'Playlist',
      count: '326 songs',
      imageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745',
      isPinned: true,
    },
    {
      id: '2',
      title: 'Your Episodes',
      type: 'Podcast',
      count: '12 episodes',
      imageUrl: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618',
      isPinned: true,
    },
  ];

  const recentItems = [
    {
      id: '3',
      title: 'Daily Mix 1',
      type: 'Playlist',
      description: 'Made for you',
      imageUrl: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d',
    },
    {
      id: '4',
      title: 'Discover Weekly',
      type: 'Playlist',
      description: 'Updated every Monday',
      imageUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f',
    },
  ];

  return (
    <View style={styles.container}>
      <Header />
      <View style={styles.content}>
        <View style={styles.toolbar}>
          <View style={styles.filterSection}>
            <TouchableOpacity style={styles.filterButton}>
              <Music2 size={20} color="#fff" />
              <Text style={styles.filterText}>Playlists</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterButton}>
              <Clock size={20} color="#fff" />
              <Text style={styles.filterText}>Recent</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.toolbarButtons}>
            <TouchableOpacity style={styles.iconButton}>
              <Filter size={24} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton}>
              <ArrowUpDown size={24} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView style={styles.libraryContent}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Pinned</Text>
            {pinnedItems.map((item) => (
              <TouchableOpacity key={item.id} style={styles.libraryItem}>
                <Image source={{ uri: item.imageUrl }} style={styles.itemImage} />
                <View style={styles.itemInfo}>
                  <Text style={styles.itemTitle}>{item.title}</Text>
                  <View style={styles.itemMeta}>
                    <Pin size={16} color="#1DB954" />
                    <Text style={styles.itemType}>{item.type}</Text>
                    <Text style={styles.itemCount}> • {item.count}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Recent</Text>
            {recentItems.map((item) => (
              <TouchableOpacity key={item.id} style={styles.libraryItem}>
                <Image source={{ uri: item.imageUrl }} style={styles.itemImage} />
                <View style={styles.itemInfo}>
                  <Text style={styles.itemTitle}>{item.title}</Text>
                  <Text style={styles.itemDescription}>{item.description}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
      <MiniPlayer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  content: {
    flex: 1,
  },
  toolbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 8,
  },
  filterSection: {
    flexDirection: 'row',
    gap: 8,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#282828',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
  },
  filterText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  toolbarButtons: {
    flexDirection: 'row',
    gap: 16,
  },
  iconButton: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  libraryContent: {
    flex: 1,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    color: '#b3b3b3',
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 16,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  libraryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  itemImage: {
    width: 56,
    height: 56,
    borderRadius: 4,
  },
  itemInfo: {
    marginLeft: 12,
    flex: 1,
  },
  itemTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  itemMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
    gap: 4,
  },
  itemType: {
    color: '#b3b3b3',
    fontSize: 14,
  },
  itemCount: {
    color: '#b3b3b3',
    fontSize: 14,
  },
  itemDescription: {
    color: '#b3b3b3',
    fontSize: 14,
    marginTop: 4,
  },
});