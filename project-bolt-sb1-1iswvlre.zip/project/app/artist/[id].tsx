import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Play, Heart } from 'lucide-react-native';
import { getArtist, getArtistSongs } from '@/data/songs';
import MiniPlayer from '@/components/MiniPlayer';

export default function ArtistScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  
  const artist = getArtist(id as string);
  const songs = getArtistSongs(id as string);

  if (!artist) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Artist not found</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        <Image source={{ uri: artist.image }} style={styles.artistImage} />
        <View style={styles.header}>
          <Text style={styles.artistName}>{artist.name}</Text>
          <Text style={styles.bio}>{artist.bio}</Text>
          <TouchableOpacity style={styles.playButton}>
            <Play size={24} color="#000" fill="#000" />
            <Text style={styles.playButtonText}>Play</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.songsSection}>
          <Text style={styles.sectionTitle}>Popular Songs</Text>
          {songs.map((song) => (
            <TouchableOpacity
              key={song.id}
              style={styles.songItem}
              onPress={() => {
                // Handle song play
              }}>
              <Image source={{ uri: song.albumArt }} style={styles.songImage} />
              <View style={styles.songInfo}>
                <Text style={styles.songTitle}>{song.title}</Text>
                <Text style={styles.songArtist}>{song.artist}</Text>
              </View>
              <Text style={styles.songDuration}>{song.duration}</Text>
              <Heart size={24} color="#b3b3b3" />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
      <MiniPlayer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  content: {
    flex: 1,
  },
  artistImage: {
    width: '100%',
    height: 300,
  },
  header: {
    padding: 16,
  },
  artistName: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  bio: {
    color: '#b3b3b3',
    fontSize: 16,
    marginBottom: 16,
  },
  playButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1DB954',
    padding: 12,
    borderRadius: 24,
    alignSelf: 'flex-start',
    gap: 8,
  },
  playButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
  songsSection: {
    padding: 16,
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  songItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  songImage: {
    width: 48,
    height: 48,
    borderRadius: 4,
  },
  songInfo: {
    flex: 1,
  },
  songTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  songArtist: {
    color: '#b3b3b3',
    fontSize: 14,
  },
  songDuration: {
    color: '#b3b3b3',
    fontSize: 14,
    marginRight: 12,
  },
  errorText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 32,
  },
});