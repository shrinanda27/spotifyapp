import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Play, Heart, MoveVertical as MoreVertical, Pause } from 'lucide-react-native';
import { playlists } from '@/data/songs';
import MiniPlayer from '@/components/MiniPlayer';
import { useAudioContext } from '@/context/AudioContext';

export default function PlaylistScreen() {
  const { id } = useLocalSearchParams();
  const playlist = playlists.find(p => p.id === id);
  const { playSound, currentSong, isPlaying, togglePlayPause, likedSongs, toggleLike } = useAudioContext();

  if (!playlist) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Playlist not found</Text>
      </View>
    );
  }

  const isCurrentPlaylist = currentSong && playlist.songs.some(song => song.id === currentSong.id);

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content}>
        <View style={styles.header}>
          <Image source={{ uri: playlist.coverImage }} style={styles.playlistImage} />
          <Text style={styles.playlistName}>{playlist.name}</Text>
          <Text style={styles.songCount}>{playlist.songs.length} songs</Text>
          
          <View style={styles.actions}>
            <TouchableOpacity 
              style={styles.playButton}
              onPress={() => {
                if (isCurrentPlaylist && isPlaying) {
                  togglePlayPause();
                } else {
                  playSound(playlist.songs[0]);
                }
              }}>
              {isCurrentPlaylist && isPlaying ? (
                <Pause size={24} color="#000" fill="#000" />
              ) : (
                <Play size={24} color="#000" fill="#000" />
              )}
              <Text style={styles.playButtonText}>
                {isCurrentPlaylist && isPlaying ? 'Pause' : 'Play'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.songsList}>
          {playlist.songs.map((song, index) => (
            <TouchableOpacity 
              key={song.id} 
              style={styles.songItem}
              onPress={() => playSound(song)}>
              <Text style={styles.songIndex}>{index + 1}</Text>
              <Image source={{ uri: song.albumArt }} style={styles.songImage} />
              <View style={styles.songInfo}>
                <Text style={[
                  styles.songTitle,
                  currentSong?.id === song.id && styles.currentSongTitle
                ]}>{song.title}</Text>
                <Text style={styles.songArtist}>{song.artist}</Text>
              </View>
              <Text style={styles.songDuration}>{song.duration}</Text>
              <TouchableOpacity onPress={() => toggleLike(song.id)}>
                <Heart 
                  size={24} 
                  color={likedSongs.has(song.id) ? '#1DB954' : '#b3b3b3'}
                  fill={likedSongs.has(song.id) ? '#1DB954' : 'none'}
                />
              </TouchableOpacity>
              <TouchableOpacity>
                <MoreVertical size={24} color="#b3b3b3" />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
      <MiniPlayer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  content: {
    flex: 1,
  },
  header: {
    padding: 16,
    alignItems: 'center',
  },
  playlistImage: {
    width: 200,
    height: 200,
    borderRadius: 8,
    marginBottom: 16,
  },
  playlistName: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  songCount: {
    color: '#b3b3b3',
    fontSize: 14,
    marginBottom: 16,
  },
  actions: {
    flexDirection: 'row',
    gap: 16,
  },
  playButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1DB954',
    padding: 12,
    borderRadius: 24,
    gap: 8,
  },
  playButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
  },
  songsList: {
    padding: 16,
  },
  songItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  songIndex: {
    color: '#b3b3b3',
    fontSize: 16,
    width: 24,
    textAlign: 'right',
  },
  songImage: {
    width: 48,
    height: 48,
    borderRadius: 4,
  },
  songInfo: {
    flex: 1,
  },
  songTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  currentSongTitle: {
    color: '#1DB954',
  },
  songArtist: {
    color: '#b3b3b3',
    fontSize: 14,
  },
  songDuration: {
    color: '#b3b3b3',
    fontSize: 14,
    marginRight: 12,
  },
  errorText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 32,
  },
});