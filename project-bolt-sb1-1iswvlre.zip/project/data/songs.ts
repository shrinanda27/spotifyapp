// Dummy song data structure
export interface Song {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  duration: string;
  albumArt: string;
  audioUrl: string;
}

export interface Artist {
  id: string;
  name: string;
  image: string;
  bio: string;
}

export interface Playlist {
  id: string;
  name: string;
  songs: Song[];
  coverImage: string;
}

// Free music from pixabay.com (Creative Commons)
export const artists: Artist[] = [
  {
    id: '1',
    name: 'Electronic Dreams',
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745',
    bio: 'Electronic music producer known for ambient soundscapes and rhythmic beats.',
  },
  {
    id: '2',
    name: 'Acoustic Vibes',
    image: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d',
    bio: 'Acoustic artist creating melodic and peaceful guitar compositions.',
  },
  {
    id: '3',
    name: 'Jazz Ensemble',
    image: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629',
    bio: 'A collective of jazz musicians bringing smooth jazz to life.',
  },
];

export const songs: Song[] = [
  // Electronic Dreams songs
  {
    id: '1',
    title: 'Digital Sunset',
    artist: 'Electronic Dreams',
    artistId: '1',
    duration: '3:45',
    albumArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_dc39bde48d.mp3',
  },
  {
    id: '2',
    title: 'Neon Lights',
    artist: 'Electronic Dreams',
    artistId: '1',
    duration: '4:20',
    albumArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3',
  },
  
  // Acoustic Vibes songs
  {
    id: '3',
    title: 'Mountain Echo',
    artist: 'Acoustic Vibes',
    artistId: '2',
    duration: '3:30',
    albumArt: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/02/22/audio_c6b1a7c12c.mp3',
  },
  {
    id: '4',
    title: 'Wooden Hearts',
    artist: 'Acoustic Vibes',
    artistId: '2',
    duration: '4:15',
    albumArt: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2021/11/25/audio_5c6b7c1b25.mp3',
  },
  
  // Jazz Ensemble songs
  {
    id: '5',
    title: 'Midnight Blues',
    artist: 'Jazz Ensemble',
    artistId: '3',
    duration: '5:30',
    albumArt: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/03/19/audio_2c0d656e59.mp3',
  },
  {
    id: '6',
    title: 'Smooth Sailing',
    artist: 'Jazz Ensemble',
    artistId: '3',
    duration: '4:45',
    albumArt: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/01/26/audio_2b8e7c62fa.mp3',
  },
];

export const playlists: Playlist[] = [
  {
    id: '1',
    name: 'Chill Mix',
    songs: [songs[0], songs[2], songs[4]],
    coverImage: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745',
  },
  {
    id: '2',
    name: 'Focus Time',
    songs: [songs[1], songs[3], songs[5]],
    coverImage: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d',
  },
];

export function searchSongs(query: string): Song[] {
  const lowercaseQuery = query.toLowerCase();
  return songs.filter(
    song =>
      song.title.toLowerCase().includes(lowercaseQuery) ||
      song.artist.toLowerCase().includes(lowercaseQuery)
  );
}

export function getArtistSongs(artistId: string): Song[] {
  return songs.filter(song => song.artistId === artistId);
}

export function getArtist(artistId: string): Artist | undefined {
  return artists.find(artist => artist.id === artistId);
}