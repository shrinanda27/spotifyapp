import { createContext, useContext, ReactNode, useState } from 'react';
import { Song } from '@/data/songs';
import { useAudioPlayer } from '@/components/AudioPlayer';

interface AudioContextType {
  playSound: (song: Song) => Promise<void>;
  pauseSound: () => Promise<void>;
  resumeSound: () => Promise<void>;
  togglePlayPause: () => Promise<void>;
  currentSong: Song | null;
  isPlaying: boolean;
  likedSongs: Set<string>;
  toggleLike: (songId: string) => void;
}

const AudioContext = createContext<AudioContextType | null>(null);

export function AudioProvider({ children }: { children: ReactNode }) {
  const {
    playSound,
    pauseSound,
    resumeSound,
    togglePlayPause,
    currentSong,
    isPlaying,
  } = useAudioPlayer();

  const [likedSongs, setLikedSongs] = useState(new Set<string>());

  const toggleLike = (songId: string) => {
    setLikedSongs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(songId)) {
        newSet.delete(songId);
      } else {
        newSet.add(songId);
      }
      return newSet;
    });
  };

  return (
    <AudioContext.Provider
      value={{
        playSound,
        pauseSound,
        resumeSound,
        togglePlayPause,
        currentSong,
        isPlaying,
        likedSongs,
        toggleLike,
      }}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudioContext() {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudioContext must be used within an AudioProvider');
  }
  return context;
}