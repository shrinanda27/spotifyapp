import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { useRouter, usePathname } from 'expo-router';
import { Chrome as Home, Search, Library, Heart, List, Settings } from 'lucide-react-native';

export default function Sidebar() {
  const router = useRouter();
  const pathname = usePathname();

  const menuItems = [
    { icon: Home, label: 'Home', route: '/' },
    { icon: Search, label: 'Search', route: '/search' },
    { icon: Library, label: 'Your Library', route: '/library' },
    { icon: Heart, label: 'Liked Songs', route: '/liked' },
    { icon: List, label: 'Playlists', route: '/playlists' },
    { icon: Settings, label: 'Settings', route: '/settings' },
  ];

  return (
    <View style={styles.sidebar}>
      <ScrollView style={styles.menuScroll}>
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = pathname === item.route;
          
          return (
            <TouchableOpacity
              key={index}
              style={[styles.menuItem, isActive && styles.activeMenuItem]}
              onPress={() => router.push(item.route)}>
              <Icon
                size={24}
                color={isActive ? '#1DB954' : '#b3b3b3'}
              />
              <Text style={[styles.menuText, isActive && styles.activeMenuText]}>
                {item.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  sidebar: {
    width: 280,
    backgroundColor: '#121212',
    borderRightWidth: 1,
    borderRightColor: '#282828',
  },
  menuScroll: {
    flex: 1,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  activeMenuItem: {
    backgroundColor: '#282828',
  },
  menuText: {
    color: '#b3b3b3',
    fontSize: 16,
    fontWeight: '500',
  },
  activeMenuText: {
    color: '#fff',
    fontWeight: '600',
  },
});