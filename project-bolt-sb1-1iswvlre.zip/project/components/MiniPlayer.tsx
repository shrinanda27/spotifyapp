import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Play, SkipBack, SkipForward, Pause, Heart } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useAudioContext } from '@/context/AudioContext';

export default function MiniPlayer() {
  const router = useRouter();
  const { currentSong, isPlaying, togglePlayPause, likedSongs, toggleLike } = useAudioContext();

  if (!currentSong) return null;

  return (
    <TouchableOpacity 
      style={styles.miniPlayer}
      onPress={() => router.push('/player')}>
      <View style={styles.songInfo}>
        <Image
          source={{ uri: currentSong.albumArt }}
          style={styles.albumArt}
        />
        <View style={styles.textContainer}>
          <Text style={styles.songTitle}>{currentSong.title}</Text>
          <Text style={styles.artistName}>{currentSong.artist}</Text>
        </View>
      </View>
      
      <View style={styles.controls}>
        <TouchableOpacity 
          style={styles.likeButton}
          onPress={() => toggleLike(currentSong.id)}>
          <Heart 
            size={24} 
            color={likedSongs.has(currentSong.id) ? '#1DB954' : '#fff'} 
            fill={likedSongs.has(currentSong.id) ? '#1DB954' : 'none'} 
          />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.playButton} onPress={togglePlayPause}>
          {isPlaying ? (
            <Pause size={24} color="#000" fill="#000" />
          ) : (
            <Play size={24} color="#000" fill="#000" />
          )}
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  miniPlayer: {
    height: 64,
    backgroundColor: '#282828',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: '#121212',
  },
  songInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  albumArt: {
    width: 48,
    height: 48,
    borderRadius: 4,
  },
  textContainer: {
    marginLeft: 12,
    flex: 1,
  },
  songTitle: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  artistName: {
    color: '#b3b3b3',
    fontSize: 12,
    marginTop: 4,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  likeButton: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#1DB954',
    justifyContent: 'center',
    alignItems: 'center',
  },
});