import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Search, Bell, Clock } from 'lucide-react-native';
import { useRouter } from 'expo-router';

export default function Header() {
  const router = useRouter();

  return (
    <View style={styles.header}>
      <View style={styles.leftSection}>
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1611339555312-e607c8352fd7' }}
          style={styles.logo}
        />
      </View>
      <View style={styles.rightSection}>
        <TouchableOpacity onPress={() => router.push('/notifications')} style={styles.iconButton}>
          <Bell size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/recent')} style={styles.iconButton}>
          <Clock size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/search')} style={styles.iconButton}>
          <Search size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/profile')} style={styles.profileButton}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde' }}
            style={styles.profilePic}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    backgroundColor: '#121212',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 108,
    height: 32,
    resizeMode: 'contain',
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  iconButton: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    overflow: 'hidden',
  },
  profilePic: {
    width: '100%',
    height: '100%',
  },
});